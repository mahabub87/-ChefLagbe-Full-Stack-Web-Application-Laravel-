<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DemoPaymentController extends Controller
{
    private $chefs = [
        1 => ['name' => 'Chef Ahmed Hossain', 'price' => 5000],
        2 => ['name' => 'Chef Asad Latif',   'price' => 3000],
        3 => ['name' => 'Chef Kabir',        'price' => 2500],
        4 => ['name' => 'Chef Tony',         'price' => 4000],
        5 => ['name' => 'Chef Manik Miah',   'price' => 4500],
        6 => ['name' => 'Chef Baisab',       'price' => 4200],
    ];

    public function showBooking($id)
    {
        $chef = $this->chefs[$id] ?? abort(404);
        return view('book_chef', compact('chef', 'id'));
    }

    public function chooseMethod(Request $request, $id)
    {
        $request->validate([
            'hours' => 'required|numeric|min:1',
            'name'  => 'required',
            'phone' => 'required',
            'method'=> 'required|in:bkash,nagad,rocket,card,nexus,upay,bank',
        ]);

        $chef  = $this->chefs[$id];
        $hours = $request->hours;
        $total = $chef['price'] * $hours;

        return view('demo_payment', compact('chef', 'hours', 'total', 'request'));
    }

    public function processPayment(Request $request)
    {
        $request->validate([
            'otp_or_pin' => 'required|numeric|digits:4',
        ]);

        // Fake success - you can save booking to DB here in real project
        return redirect('/payment-success');
    }
}