<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    // Show registration page
    public function register() {
        return view('register');
    }

    // Handle registration
    public function registerUser(Request $request)
    {
        $request->validate([
    'firstName' => 'required|string|max:255',
    'lastName'  => 'required|string|max:255',
    'email'     => 'required|email|unique:users,email',
    'password'  => 'required|min:6|confirmed', // confirmed = checks password_confirmation
    'phone'     => 'nullable|string|max:20',
    'location'  => 'nullable|string|max:255',
    'userType'  => 'required|in:customer,chef',
]);


        $user = User::create([
    'first_name' => $request->firstName,
    'last_name'  => $request->lastName,
    'name'       => $request->firstName . ' ' . $request->lastName,
    'email'      => $request->email,
    'password'   => Hash::make($request->password),
    'phone'      => $request->phone,
    'location'   => $request->location,
    'user_type'  => $request->userType,
]);


        if($user) {
            return redirect('login')->with('success', 'Account created successfully! Please login.');
        } else {
            return back()->with('fail', 'Something went wrong, try again.');
        }
    }

    // Show login page
    public function login() {
        return view('login');
    }

    // Handle login
    public function loginUser(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required'
        ]);

        $user = User::where('email', $request->email)->first();

        if ($user && Hash::check($request->password, $user->password)) {
    Session::put('loginId', $user->id);
    return redirect('welcome')->with('success', 'Login successfully!');
} else {
    return back()->with('fail', 'Invalid email or password.');
}
    }

    // Logout
    public function logout()
    {
        Session::forget('loginId');
        return redirect('login')->with('success', 'Logged out successfully.');
    }
}
