<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\DemoPaymentController;

// --------------------------------------------------
// HOME REDIRECT
// --------------------------------------------------
Route::get('/', function () {
    return redirect('/login');
});

// --------------------------------------------------
// AUTH ROUTES
// --------------------------------------------------

// Register
Route::get('/register', [AuthController::class, 'register'])->name('register');
Route::post('/register', [AuthController::class, 'registerUser'])->name('register.user');

// Login
Route::get('/login', [AuthController::class, 'login'])->name('login');
Route::post('/login', [AuthController::class, 'loginUser'])->name('login.user');

// Logout
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

// --------------------------------------------------
// PROTECTED ROUTES
// --------------------------------------------------

// Helper function to protect routes with login session
$protectedRoute = function ($view) {
    if (!Session::has('loginId')) {
        return redirect('/login')->with('fail', 'You must login first');
    }
    return view($view);
};

// Other pages (after login)
Route::get('/welcome', fn() => $protectedRoute('welcome'))->name('welcome');
Route::get('/about', fn() => $protectedRoute('about'))->name('about');
Route::get('/contact', fn() => $protectedRoute('contact'))->name('contact');
Route::get('/chefs', fn() => $protectedRoute('chefs'))->name('chefs');
Route::get('/services', fn() => $protectedRoute('services'))->name('services');

// --------------------------------------------------
// TEST ROUTE
// --------------------------------------------------
Route::get('/test123', function () {
    return "ROUTE WORKING";
});

// --------------------------------------------------
// DEMO PAYMENT (Not Real Payment)
// --------------------------------------------------
Route::get('/book-chef/{id}', [DemoPaymentController::class, 'showBooking'])->name('book.chef');
Route::post('/book-chef/{id}', [DemoPaymentController::class, 'chooseMethod'])->name('book.chef.method');
Route::post('/demo-pay', [DemoPaymentController::class, 'processPayment'])->name('demo.pay');
Route::get('/payment-success', function () {
    return view('payment_success');
})->name('payment.success');
