<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Our Services - ChefLagbe</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    
    <link rel="stylesheet" href="{{asset("services.css")}}" />
    
  </head>
  <body>
    <!-- Header / Navigation Bar -->
    <header>
      <div class="container">
        <nav class="navbar">
          <a href="welcome" class="logo">
            <img src="/CheefLogo.png" alt="Logo" style="height: 60px" />
            ChefLagbe
          </a>

          <ul class="nav-links">
            <li><a href="welcome">Home</a></li>
            <li><a href="about">About</a></li>
            <li><a href="services">Services</a></li>
            <li><a href="chefs">Chefs</a></li>
            <li><a href="contact">Contact</a></li>
          </ul>


          <div class="mobile-menu">
            <i class="fas fa-bars"></i>
          </div>
        </nav>
      </div>
    </header>

    <!-- Services Hero Section -->
    <section class="services-hero">
      <div class="container">
        <div class="services-hero-content">
          <h1>Our Culinary Services</h1>
          <p>
            Discover a wide range of professional chef services tailored to your
            needs, from intimate dinners to grand events
          </p>
          <a href="#services" class="btn">Explore Services</a>
        </div>
      </div>
    </section>

    <!-- Services Grid Section -->
    <section id="services" class="section">
      <div class="container">
        <div class="section-title">
          <h2>Our Services</h2>
          <p>Professional chef services for every occasion and need</p>
        </div>

        <div class="services-grid">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-home"></i>
            </div>
            <div class="service-content">
              <h3>Home Cooking</h3>
              <p>
                Enjoy restaurant-quality meals prepared in your own kitchen by
                our professional chefs.
              </p>

              <ul class="service-features">
                <li><i class="fas fa-check"></i> Customized menu planning</li>
                <li><i class="fas fa-check"></i> Grocery shopping included</li>
                <li><i class="fas fa-check"></i> Kitchen cleanup service</li>
                <li><i class="fas fa-check"></i> Dietary accommodations</li>
              </ul>

              <div class="service-price">
                Starting from ৳2000 <span>per meal</span>
              </div>

              <a href="#" class="btn">Book Now</a>
            </div>
          </div>

          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-calendar-alt"></i>
            </div>
            <div class="service-content">
              <h3>Event Chef</h3>
              <p>
                Make your special occasions unforgettable with our expert event
                chefs.
              </p>

              <ul class="service-features">
                <li><i class="fas fa-check"></i> Personalized menu creation</li>
                <li><i class="fas fa-check"></i> Professional presentation</li>
                <li><i class="fas fa-check"></i> Staff coordination</li>
                <li><i class="fas fa-check"></i> Event timeline management</li>
              </ul>

              <div class="service-price">
                Starting from ৳3000 <span>per event</span>
              </div>

              <a href="#" class="btn">Book Now</a>
            </div>
          </div>

          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-users"></i>
            </div>
            <div class="service-content">
              <h3>Catering Team</h3>
              <p>
                Full-service catering for corporate events, weddings, and large
                gatherings.
              </p>

              <ul class="service-features">
                <li><i class="fas fa-check"></i> Complete event planning</li>
                <li><i class="fas fa-check"></i> Professional serving staff</li>
                <li>
                  <i class="fas fa-check"></i> Equipment rental coordination
                </li>
                <li><i class="fas fa-check"></i> Venue setup and cleanup</li>
              </ul>

              <div class="service-price">
                Starting from ৳5000 <span>per event</span>
              </div>

              <a href="#" class="btn">Book Now</a>
            </div>
          </div>

          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-utensil-spoon"></i>
            </div>
            <div class="service-content">
              <h3>Cooking Classes</h3>
              <p>
                Learn culinary skills from professional chefs in interactive
                cooking sessions.
              </p>

              <ul class="service-features">
                <li>
                  <i class="fas fa-check"></i> Hands-on learning experience
                </li>
                <li><i class="fas fa-check"></i> Small group sessions</li>
                <li><i class="fas fa-check"></i> Recipe guides to take home</li>
                <li><i class="fas fa-check"></i> All ingredients provided</li>
              </ul>

              <div class="service-price">
                Starting from ৳4000 <span>per person</span>
              </div>

              <a href="#" class="btn">Book Now</a>
            </div>
          </div>

          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-clipboard-list"></i>
            </div>
            <div class="service-content">
              <h3>Meal Planning</h3>
              <p>
                Customized weekly meal plans and preparation services for busy
                individuals and families.
              </p>

              <ul class="service-features">
                <li>
                  <i class="fas fa-check"></i> Personalized nutrition plans
                </li>
                <li><i class="fas fa-check"></i> Weekly grocery lists</li>
                <li><i class="fas fa-check"></i> Meal prep services</li>
                <li>
                  <i class="fas fa-check"></i> Dietary restriction
                  accommodations
                </li>
              </ul>

              <div class="service-price">
                Starting from ৳7000 <span>per week</span>
              </div>

              <a href="#" class="btn">Book Now</a>
            </div>
          </div>

          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-concierge-bell"></i>
            </div>
            <div class="service-content">
              <h3>Private Dining</h3>
              <p>
                Exclusive dining experiences with personalized service in the
                comfort of your home.
              </p>

              <ul class="service-features">
                <li><i class="fas fa-check"></i> Multi-course gourmet meals</li>
                <li>
                  <i class="fas fa-check"></i> Wine pairing recommendations
                </li>
                <li><i class="fas fa-check"></i> Tableside service</li>
                <li><i class="fas fa-check"></i> Ambiance creation</li>
              </ul>

              <div class="service-price">
                Starting from ৳10,000 <span>per experience</span>
              </div>

              <a href="#" class="btn">Book Now</a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- How It Works Section -->
    <section class="section process-section">
      <div class="container">
        <div class="section-title">
          <h2>How It Works</h2>
          <p>Getting a professional chef has never been easier</p>
        </div>

        <div class="steps">
          <div class="step">
            <div class="step-number">1</div>
            <h3>Browse & Select</h3>
            <p>Explore our services and choose the one that fits your needs</p>
          </div>

          <div class="step">
            <div class="step-number">2</div>
            <h3>Customize</h3>
            <p>Share your preferences, dietary needs, and event details</p>
          </div>

          <div class="step">
            <div class="step-number">3</div>
            <h3>Book & Pay</h3>
            <p>Schedule your service with our secure online payment system</p>
          </div>

          <div class="step">
            <div class="step-number">4</div>
            <h3>Enjoy</h3>
            <p>Sit back and enjoy exceptional food prepared by your chef</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Pricing Section -->
    <section class="section">
      <div class="container">
        <div class="section-title">
          <h2>Service Packages</h2>
          <p>Flexible pricing options for every budget and occasion</p>
        </div>

        <div class="pricing-grid">
          <div class="pricing-card">
            <div class="pricing-header">
              <h3>Basic</h3>
              <div class="price">৳2000</div>
              <div class="period">per meal</div>
            </div>
            <div class="pricing-features">
              <ul>
                <li><i class="fas fa-check"></i> 1 Chef for up to 4 people</li>
                <li><i class="fas fa-check"></i> Custom 3-course menu</li>
                <li><i class="fas fa-check"></i> 3 hours of service</li>
                <li><i class="fas fa-check"></i> Basic kitchen cleanup</li>
                <li class="not-included">
                  <i class="fas fa-times"></i> Grocery shopping
                </li>
                <li class="not-included">
                  <i class="fas fa-times"></i> Special dietary planning
                </li>
              </ul>
              <a href="#" class="btn btn-outline" style="width: 100%"
                >Select Plan</a
              >
            </div>
          </div>

          <div class="pricing-card featured">
            <div class="pricing-header">
              <h3>Premium</h3>
              <div class="price">৳3000</div>
              <div class="period">per meal</div>
            </div>
            <div class="pricing-features">
              <ul>
                <li><i class="fas fa-check"></i> 1 Chef for up to 8 people</li>
                <li><i class="fas fa-check"></i> Custom 4-course menu</li>
                <li><i class="fas fa-check"></i> 4 hours of service</li>
                <li><i class="fas fa-check"></i> Full kitchen cleanup</li>
                <li><i class="fas fa-check"></i> Grocery shopping included</li>
                <li><i class="fas fa-check"></i> Special dietary planning</li>
              </ul>
              <a href="#" class="btn" style="width: 100%">Select Plan</a>
            </div>
          </div>

          <div class="pricing-card">
            <div class="pricing-header">
              <h3>Elite</h3>
              <div class="price">৳5000</div>
              <div class="period">per meal</div>
            </div>
            <div class="pricing-features">
              <ul>
                <li>
                  <i class="fas fa-check"></i> 2 Chefs for up to 15 people
                </li>
                <li><i class="fas fa-check"></i> Custom 5-course menu</li>
                <li><i class="fas fa-check"></i> 5 hours of service</li>
                <li><i class="fas fa-check"></i> Full kitchen cleanup</li>
                <li>
                  <i class="fas fa-check"></i> Premium ingredient selection
                </li>
                <li><i class="fas fa-check"></i> Wine pairing suggestions</li>
              </ul>
              <a href="#" class="btn btn-outline" style="width: 100%"
                >Select Plan</a
              >
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- FAQ Section -->
    <section class="section faq-section">
      <div class="container">
        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
          <p>Find answers to common questions about our services</p>
        </div>

        <div class="faq-container">
          <div class="faq-item active">
            <div class="faq-question">
              <span>How far in advance should I book a chef?</span>
              <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
              <p>
                We recommend booking at least 2 weeks in advance for standard
                services and 4-6 weeks for large events or during peak seasons.
                However, we do accommodate last-minute requests based on chef
                availability.
              </p>
            </div>
          </div>

          <div class="faq-item">
            <div class="faq-question">
              <span>Can you accommodate dietary restrictions?</span>
              <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
              <p>
                Absolutely! All our chefs are trained to accommodate various
                dietary needs including vegetarian, vegan, gluten-free,
                dairy-free, and specific allergies. Please share your
                requirements during the booking process.
              </p>
            </div>
          </div>

          <div class="faq-item">
            <div class="faq-question">
              <span>What areas do you serve?</span>
              <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
              <p>
                We currently serve all major cities across Bangladesh including
                Dhaka, Chittagong, Sylhet, and Rajshahi. Service availability in
                specific locations can be checked during the booking process.
              </p>
            </div>
          </div>

          <div class="faq-item">
            <div class="faq-question">
              <span>What is included in the service fee?</span>
              <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
              <p>
                The service fee includes the chef's time, expertise, and basic
                cleanup. Groceries, specialty ingredients, and equipment rentals
                are additional costs that will be discussed and approved before
                your booking is confirmed.
              </p>
            </div>
          </div>

          <div class="faq-item">
            <div class="faq-question">
              <span>Can I request a specific chef?</span>
              <i class="fas fa-chevron-down"></i>
            </div>
            <div class="faq-answer">
              <p>
                Yes, you can request a specific chef based on their profile,
                cuisine specialty, or previous reviews. We'll do our best to
                accommodate your preference based on the chef's availability.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
      <div class="container">
        <h2>Ready to Book Your Chef?</h2>
        <p>
          Join thousands of satisfied customers who have discovered the joy of
          professional chef services
        </p>
        <div class="cta-buttons">
          <a href="signup" class="btn">Sign Up Now</a>
          <a
            href="#"
            class="btn btn-outline"
            style="
              background-color: transparent;
              border: 2px solid white;
              color: white;
            "
            >Contact Us</a
          >
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="footer-content">
          <div class="footer-column">
            <h3>ChefLagbe</h3>
            <p>
              Connecting food lovers with professional chefs for exceptional
              culinary experiences at home or events.
            </p>
            <div class="social-links">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
          </div>

          <div class="footer-column">
            <h3>Quick Links</h3>
            <ul class="footer-links">
              <li><a href="welcome">Home</a></li>
              <li><a href="about">About Us</a></li>
              <li><a href="services">Services</a></li>
              <li><a href="chefs">Chefs</a></li>
              <li><a href="contact">Contact</a></li>
            </ul>
          </div>

          <div class="footer-column">
            <h3>Services</h3>
            <ul class="footer-links">
              <li><a href="#">Home Cooking</a></li>
              <li><a href="#">Event Chef</a></li>
              <li><a href="#">Catering Team</a></li>
              <li><a href="#">Cooking Classes</a></li>
              <li><a href="#">Meal Planning</a></li>
            </ul>
          </div>

          <div class="footer-column">
            <h3>Contact Us</h3>
            <ul class="footer-links">
              <li>
                <i class="fas fa-map-marker-alt"></i> Daffodil Smart City (DSC), Dhaka,Bangladesh
              </li>
              <li><i class="fas fa-phone"></i> +880 1797753943</li>
              <li><i class="fas fa-envelope"></i> info@cheflagbe.com</li>
            </ul>
          </div>
        </div>

        <div class="footer-bottom">
          <p>&copy; 2025 ChefLagbe. All rights reserved.</p>
        </div>
      </div>
    </footer>
  </body>
</html>
