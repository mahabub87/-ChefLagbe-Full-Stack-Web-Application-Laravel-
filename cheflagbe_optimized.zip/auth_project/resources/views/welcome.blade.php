<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ChefLagbe - Homepage</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />

    <link rel="stylesheet" href="{{asset("style.css")}}" />
  </head>
  <body>
    <!-- Header / Navigation Bar -->
     
    <header>
      <div class="container">
        <nav class="navbar">
          <a href="welcome" class="logo">
            <img src="/CheefLogo.png" alt="Logo" style="height: 60px" />
            ChefLagbe
          </a>

          <ul class="nav-links">
            <li><a href="welcome">Home</a></li>
            <li><a href="about">About</a></li>
            <li><a href="services">Services</a></li>
            <li><a href="chefs">Chefs</a></li>
            <li><a href="contact">Contact</a></li>
          </ul>


          <div class="mobile-menu">
            <i class="fas fa-bars"></i>
          </div>
        </nav>
      </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1>Find the Perfect Chef for Your Occasion</h1>
          <p>
            Professional chefs for home cooking, events, and catering services
          </p>

          <div class="search-bar">
            <input
              type="text"
              placeholder="Search by location or event type..."
            />
            <button><i class="fas fa-search"></i></button>
          </div>

          <div class="hero-buttons">
            <a href="login" class="btn">Hire a Chef</a>
          </div>
        </div>
      </div>
    </section>

    <!-- Services Section -->
    <section class="section">
      <div class="container">
        <div class="section-title">
          <h2>Our Services</h2>
          <p>We offer a variety of chef services to meet your culinary needs</p>
        </div>

        <div class="services-grid">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-home"></i>
            </div>
            <div class="service-content">
              <h3>Home Cooking</h3>
              <p>
                Enjoy restaurant-quality meals in the comfort of your home with
                our professional home chefs.
              </p>
            </div>
          </div>

          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-calendar-alt"></i>
            </div>
            <div class="service-content">
              <h3>Event Chef</h3>
              <p>
                Make your special occasions memorable with our expert event
                chefs for parties and gatherings.
              </p>
            </div>
          </div>

          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-users"></i>
            </div>
            <div class="service-content">
              <h3>Catering Team</h3>
              <p>
                Full-service catering for corporate events, weddings, and large
                gatherings with professional teams.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- How It Works Section -->
    <section class="section" style="background-color: #f8f9fa">
      <div class="container">
        <div class="section-title">
          <h2>How It Works</h2>
          <p>Getting a professional chef has never been easier</p>
        </div>

        <div class="steps">
          <div class="step">
            <div class="step-number">1</div>
            <h3>Search</h3>
            <p>Find chefs by location, cuisine, or event type</p>
          </div>

          <div class="step">
            <div class="step-number">2</div>
            <h3>Select</h3>
            <p>Compare profiles, ratings, and menus to choose your chef</p>
          </div>

          <div class="step">
            <div class="step-number">3</div>
            <h3>Book</h3>
            <p>Schedule your service with secure online payment</p>
          </div>

          <div class="step">
            <div class="step-number">4</div>
            <h3>Enjoy</h3>
            <p>Sit back and enjoy delicious food prepared by your chef</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Featured Chefs Section -->
    <section class="section">
      <div class="container">
        <div class="section-title">
          <h2>Featured Chefs</h2>
          <p>Meet some of our top-rated professional chefs</p>
        </div>

        <div class="chefs-grid">
          <div class="chef-card">
            <div
              class="chef-img"
              style="background-image: url('https://www.opentable.com/blog/wp-content/uploads/sites/108/2023/04/oak-long-bar-kitchen-2.jpg')"
            ></div>
            <div class="chef-info">
              <h3>Chef Jahed Khan</h3>
              <p class="chef-specialty">Italian & Mediterranean Cuisine</p>
              <div class="chef-rating">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
                <span>4.5 (128 reviews)</span>
              </div>
              <p class="chef-price">From 3000(Tk)/hour</p>
            </div>
          </div>

          <div class="chef-card">
            <div
              class="chef-img"
              style="background-image: url('https://thetoptenchefs.com/wp/wp-content/uploads/2016/10/Chef-Ahmed-Hossain-top-10-chefs-in-Bangladesh.jpg')"
            ></div>
            <div class="chef-info">
              <h3>Chef Ahmed Hossain</h3>
              <p class="chef-specialty">French & Fusion Cuisine</p>
              <div class="chef-rating">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <span>5.0 (96 reviews)</span>
              </div>
              <p class="chef-price">From 5000(Tk)/hour</p>
            </div>
          </div>

          <div class="chef-card">
            <div
              class="chef-img"
              style="background-image: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhdB0QGy9rnZ0jGpmPovNeXUvC1QxB2smXxAtokZHHV3NS6w4aagNvotrXa6P59-UqQkqskJsAPLfzp4glF2d6jXAHQoZ9WfQfjwfzkAtzYw_vYhyphenhyphenjQ9tZ58BcSeQ3MNdpnZGVDBfiIDoeX/w1200-h630-p-k-no-nu/225333_141946999211179_141946479211231_281465_3375276_n.jpg')"
            ></div>
            <div class="chef-info">
              <h3>Chef Siddika Kabir</h3>
              <p class="chef-specialty">Indian & Asian Cuisine</p>
              <div class="chef-rating">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>
                <span>4.0 (142 reviews)</span>
              </div>
              <p class="chef-price">From 2500(Tk)/hour</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Why Choose Us Section -->
    <section class="section" style="background-color: #f8f9fa">
      <div class="container">
        <div class="section-title">
          <h2>Why Choose ChefLagbe</h2>
          <p>We provide the best chef hiring experience with these benefits</p>
        </div>

        <div class="features">
          <div class="feature">
            <div class="feature-icon">
              <i class="fas fa-shield-alt"></i>
            </div>
            <div class="feature-content">
              <h3>Verified Chefs</h3>
              <p>
                All our chefs are thoroughly vetted with background checks and
                verified credentials.
              </p>
            </div>
          </div>

          <div class="feature">
            <div class="feature-icon">
              <i class="fas fa-lock"></i>
            </div>
            <div class="feature-content">
              <h3>Secure Payment</h3>
              <p>
                Your payments are protected with our secure payment system and
                satisfaction guarantee.
              </p>
            </div>
          </div>

          <div class="feature">
            <div class="feature-icon">
              <i class="fas fa-clock"></i>
            </div>
            <div class="feature-content">
              <h3>Easy Booking</h3>
              <p>
                Simple and quick booking process with instant confirmation and
                flexible scheduling.
              </p>
            </div>
          </div>

          <div class="feature">
            <div class="feature-icon">
              <i class="fas fa-headset"></i>
            </div>
            <div class="feature-content">
              <h3>24/7 Support</h3>
              <p>
                Our customer support team is available around the clock to
                assist you with any issues.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- About Section -->
    <section class="section">
      <div class="container">
        <div class="about-content">
          <div class="about-text">
            <h2>About ChefLagbe</h2>
            <p>
              ChefLagbe was founded with a simple mission: to connect food
              lovers with talented chefs who can create exceptional culinary
              experiences in the comfort of their homes or at special events.
            </p>
            <p>
              We believe that everyone deserves access to restaurant-quality
              meals without the hassle of dining out. Our platform makes it easy
              to find, book, and enjoy the services of professional chefs for
              any occasion.
            </p>
            <p>
              Whether you're planning an intimate dinner, a family celebration,
              or a corporate event, ChefLagbe has the perfect chef for your
              needs.
            </p>
            <a href="#" class="btn">Learn More</a>
          </div>
          <div class="about-image"></div>
        </div>
      </div>
    </section>

    <!-- Testimonials Section -->
    <section class="section" style="background-color: #f8f9fa">
      <div class="container">
        <div class="section-title">
          <h2>Customer Testimonials</h2>
          <p>See what our customers are saying about their experiences</p>
        </div>

        <div class="testimonials">
          <div class="testimonial-card">
            <div class="testimonial-text">
              <p>
                Chef Jahed Khan prepared an amazing Italian feast for our
                anniversary dinner. The food was exceptional and the experience
                was unforgettable. Highly recommended!
              </p>
            </div>
            <div class="testimonial-author">
              <div class="author-avatar"></div>
              <div class="author-info">
                <h4>Jalal Ahemed</h4>
                <p>Anniversary Dinner</p>
              </div>
            </div>
          </div>

          <div class="testimonial-card">
            <div class="testimonial-text">
              <p>
                We hired Chef Ahmed for our corporate event and he exceeded all
                expectations. The menu was creative, the presentation was
                stunning, and our guests were impressed.
              </p>
            </div>
            <div class="testimonial-author">
              <div class="author-avatar"></div>
              <div class="author-info">
                <h4>Md. Naimul Islam</h4>
                <p>Corporate Event</p>
              </div>
            </div>
          </div>

          <div class="testimonial-card">
            <div class="testimonial-text">
              <p>
                Chef Siddika Kabir's Indian cooking classes were a fantastic
                experience. He was patient, knowledgeable, and the food we
                prepared was delicious. Can't wait to book again!
              </p>
            </div>
            <div class="testimonial-author">
              <div class="author-avatar"></div>
              <div class="author-info">
                <h4>Mehebub Rana</h4>
                <p>Cooking Class</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- App Download Section -->
    <section class="app-download">
      <div class="container">
        <a href="{{ url('/logout') }}" 
   style="display:inline-block; padding:10px 20px; background-color:#e74c3c; color:white; text-decoration:none; border-radius:5px; font-weight:bold;">
   Logout
</a>

      </div>
    </section>

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="footer-content">
          <div class="footer-column">
            <h3>ChefLagbe</h3>
            <p>
              Connecting food lovers with professional chefs for exceptional
              culinary experiences at home or events.
            </p>
            <div class="social-links">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
          </div>

          <div class="footer-column">
            <h3>Quick Links</h3>
            <ul class="footer-links">
              <li><a href="#">Home</a></li>
              <li><a href="about">About Us</a></li>
              <li><a href="services">Services</a></li>
              <li><a href="chefs">Chefs</a></li>
              <li><a href="contact">Contact</a></li>
            </ul>
          </div>

          <div class="footer-column">
            <h3>Services</h3>
            <ul class="footer-links">
              <li><a href="#">Home Cooking</a></li>
              <li><a href="#">Event Chef</a></li>
              <li><a href="#">Catering Team</a></li>
              <li><a href="#">Cooking Classes</a></li>
              <li><a href="#">Meal Planning</a></li>
            </ul>
          </div>

          <div class="footer-column">
            <h3>Contact Us</h3>
            <ul class="footer-links">
              <li>
                <i class="fas fa-map-marker-alt"></i> Daffodil Smart City (DSC),
                Dhaka,Bangladesh
              </li>
              <li><i class="fas fa-phone"></i> +880 1797753943</li>
              <li><i class="fas fa-envelope"></i> info@cheflagbe.com</li>
            </ul>
          </div>
        </div>

        <div class="footer-bottom">
          <p>&copy; 2025 ChefLagbe. All rights reserved.</p>
        </div>
      </div>
    </footer>
  </body>
</html>
