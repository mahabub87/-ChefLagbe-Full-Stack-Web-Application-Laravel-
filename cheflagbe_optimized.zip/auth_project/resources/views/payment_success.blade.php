<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - ChefLagbe</title>
    <link rel="stylesheet" href="{{ asset('chefs.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<section class="section cta" style="padding: 150px 0;">
    <div class="container" style="text-align:center; color:white;">
        <i class="fas fa-check-circle" style="font-size: 80px; margin-bottom:20px;"></i>
        <h1>Payment Successful!</h1>
        <p>Your booking has been confirmed. We will contact you shortly.</p>
        <a href="{{ url('/chefs') }}" class="btn btn-secondary" style="margin-top:20px;">Back to Chefs</a>
    </div>
</section>
</body>
</html>