<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ChefLagbe | Hire Professional Chefs in Bangladesh</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <!-- Google Font: Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #FF6B6B;
            --secondary: #FFA4A4;
            --light: #FFF7E6;
            --dark: #2c3e50;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #FFF7E6 0%, #FFE1C7 100%);
            min-height: 100vh;
        }
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        .logo img {
            height: 55px;
        }
        .logo {
            font-weight: 700;
            font-size: 1.8rem;
            color: var(--primary) !important;
            text-decoration: none;
        }
        .hero {
            padding: 80px 0 50px;
            text-align: center;
            color: var(--dark);
        }
        .hero h1 {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        .hero p {
            font-size: 1.2rem;
            max-width: 700px;
            margin: 0 auto 30px;
        }
        .search-bar {
            max-width: 600px;
            margin: 0 auto 40px;
            position: relative;
        }
        .search-bar input {
            width: 100%;
            padding: 15px 60px 15px 20px;
            border-radius: 50px;
            border: none;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            font-size: 1.1rem;
        }
        .search-bar button {
            position: absolute;
            right: 8px;
            top: 8px;
            height: 50px;
            width: 50px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            border: none;
        }
        .card-login {
            background: #FFD9C0;
            border-radius: 25px;
            padding: 40px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
            animation: fadeInUp 1s ease;
            max-width: 420px;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .btn-custom {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-custom:hover {
            background: #FF5252;
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(255,107,107,0.3);
        }
        .illustration img {
            width: 320px;
            animation: float 4s ease-in-out infinite;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-15px); }
        }
        footer {
            background: #2c3e50;
            color: white;
            padding: 60px 0 20px;
            margin-top: 100px;
        }
        .footer-column h3 {
            color: var(--primary);
            margin-bottom: 20px;
        }
        .social-links a {
            background: rgba(255,255,255,0.1);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            transition: 0.3s;
        }
        .social-links a:hover {
            background: var(--primary);
            transform: translateY(-5px);
        }
        @media (max-width: 768px) {
            .hero h1 { font-size: 2.5rem; }
            .login-wrapper { flex-direction: column; }
            .illustration { display: none; }
        }
    </style>
</head>
<body>

<!-- Navigation -->
<header class="navbar-fixed">
    <div class="container py-2">
        <nav class="d-flex justify-content-between align-items-center">
            <!-- Logo -->
            <a href="{{ url('/') }}" class="logo d-flex align-items-center text-decoration-none">
                <img src="{{ asset('CheefLogo.png') }}" alt="ChefLagbe" class="logo-img">
                <span class="logo-text fw-bold text-danger">ChefLagbe</span>
            </a>

        </nav>
    </div>
</header>

    <!-- Hero + Login Section -->
    <section class="hero">
        <div class="container">
            <h1>Find Your Perfect Chef Today</h1>
            <p>Professional home chefs, event catering, cooking classes — all in one place!</p>


            <div class="login-wrapper d-flex justify-content-center align-items-center gap-5 flex-wrap">
                <!-- Illustration -->
                <div class="illustration text-center">
                    <img src="https://cdn-icons-png.flaticon.com/512/3075/3075977.png" alt="Chef Illustration">
                    <p class="mt-3 fs-5 fw-bold text-danger">Welcome Back 👨‍🍳</p>
                </div>

                <!-- Login Card -->
                <div class="card-login">
                    <!-- Session Messages -->
                    @if(session('success'))
                        <div class="alert alert-success text-center">{{ session('success') }}</div>
                    @endif
                    @if(session('fail'))
                        <div class="alert alert-danger text-center">{{ session('fail') }}</div>
                    @endif
                    @if($errors->any())
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('login.user') }}">
                        @csrf
                        <div class="mb-4">
                            <label class="form-label fw-semibold"><i class="fa-solid fa-envelope text-danger"></i> Email</label>
                            <input type="email" name="email" class="form-control form-control-lg" placeholder="Enter your email" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold"><i class="fa-solid fa-lock text-danger"></i> Password</label>
                            <input type="password" name="password" class="form-control form-control-lg" placeholder="Enter password" required>
                        </div>

                        <button type="submit" class="btn btn-custom w-100 btn-lg">
                            <i class="fa-solid fa-right-to-bracket"></i> Login Now
                        </button>
                    </form>

                    <p class="mt-4 text-center">
                        Don't have an account?
                        <a href="{{ url('/register') }}" class="text-danger fw-bold text-decoration-none">Register Now →</a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-3 footer-column">
                    <h3>ChefLagbe</h3>
                    <p>Connecting food lovers with professional chefs for exceptional culinary experiences at home or events.</p>
                    <div class="social-links mt-3">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links list-unstyled">
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li><a href="{{ url('/about') }}">About Us</a></li>
                        <li><a href="{{ url('/services') }}">Services</a></li>
                        <li><a href="{{ url('/chefs') }}">Find Chefs</a></li>
                        <li><a href="{{ url('/contact') }}">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links list-unstyled">
                        <li>Home Cooking</li>
                        <li>Event Chef</li>
                        <li>Catering Team</li>
                        <li>Cooking Classes</li>
                        <li>Meal Planning</li>
                    </ul>
                </div>
                <div class="col-lg-3 footer-column">
                    <h3>Contact Us</h3>
                    <ul class="footer-links list-unstyled">
                        <li><i class="fas fa-map-marker-alt"></i> Daffodil Smart City, Dhaka</li>
                        <li><i class="fas fa-phone"></i> +880 01797-753943</li>
                        <li><i class="fas fa-envelope"></i> info@cheflagbe.com</li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom text-center mt-5 pt-4 border-top">
                <p>&copy; 2025 ChefLagbe. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>