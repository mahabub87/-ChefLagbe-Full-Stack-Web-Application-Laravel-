<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book {{ $chef['name'] }} - ChefLagbe</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('chefs.css') }}">
    <style>
        input, select {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        label {
            font-weight: 600;
            margin-top: 10px;
            display: block;
            color: var(--secondary);
        }
    </style>
</head>
<body>

    <!-- Header / Navigation Bar - Exactly same as chefs.blade.php -->
    <header>
      <div class="container">
        <nav class="navbar">
          <a href="{{ url('welcome') }}" class="logo">
            <img src="/CheefLogo.png" alt="Logo" style="height: 60px" />
            ChefLagbe
          </a>

          <ul class="nav-links">
            <li><a href="{{ url('welcome') }}">Home</a></li>
            <li><a href="{{ url('about') }}">About</a></li>
            <li><a href="{{ url('services') }}">Services</a></li>
            <li><a href="{{ url('chefs') }}">Chefs</a></li>
            <li><a href="{{ url('contact') }}">Contact</a></li>
          </ul>

          <div class="mobile-menu">
            <i class="fas fa-bars"></i>
          </div>
        </nav>
      </div>
    </header>

    <!-- Booking Section -->
    <section class="section" style="padding: 120px 0 80px;">
        <div class="container">
            <div class="section-title">
                <h2>Book {{ $chef['name'] }}</h2>
                <p>Fill in your details and choose a payment method to complete the booking</p>
            </div>

            <div class="chef-card" style="max-width: 750px; margin: 0 auto;">
                <div class="chef-info">
                    <form action="{{ url('/book-chef/' . $id) }}" method="POST">
                        @csrf

                        <p><strong>Hourly Rate:</strong> ৳{{ number_format($chef['price']) }} / hour</p>

                        <label>Number of Hours</label>
                        <input type="number" name="hours" min="1" value="1" required>

                        <label>Total Amount</label>
                        <h2 style="color: var(--primary); margin: 15px 0;">
                            ৳<span id="total">{{ number_format($chef['price']) }}</span>
                        </h2>

                        <label>Your Full Name</label>
                        <input type="text" name="name" placeholder="Enter your name" required>

                        <label>Phone Number</label>
                        <input type="text" name="phone" placeholder="01XXXXXXXXX" required>

                        <label>Choose Payment Method</label>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px,1fr)); gap: 18px; margin: 25px 0;">
                            <!-- bKash -->
                            <label style="text-align:center; cursor:pointer; border:2px solid #ddd; padding:18px 12px; border-radius:10px; transition: all 0.3s;">
                                <input type="radio" name="method" value="bkash" required style="display:none;">
                                <img src="https://images.seeklogo.com/logo-png/38/1/bkash-logo-png_seeklogo-382709.png" alt="bKash" style="height:45px; margin-bottom:8px;"><br>
                                <span style="font-size:0.95rem; font-weight:600;">bKash</span>
                            </label>

                            <!-- Nagad -->
                            <label style="text-align:center; cursor:pointer; border:2px solid #ddd; padding:18px 12px; border-radius:10px; transition: all 0.3s;">
                                <input type="radio" name="method" value="nagad" style="display:none;">
                                <img src="https://images.seeklogo.com/logo-png/41/1/nagad-logo-png_seeklogo-411803.png" alt="Nagad" style="height:45px; margin-bottom:8px;"><br>
                                <span style="font-size:0.95rem; font-weight:600;">Nagad</span>
                            </label>

                            <!-- Rocket -->
                            <label style="text-align:center; cursor:pointer; border:2px solid #ddd; padding:18px 12px; border-radius:10px; transition: all 0.3s;">
                                <input type="radio" name="method" value="rocket" style="display:none;">
                                <img src="https://images.seeklogo.com/logo-png/31/1/dutch-bangla-rocket-logo-png_seeklogo-317692.png" alt="Rocket" style="height:55px; margin-bottom:8px;"><br>
                                <span style="font-size:0.95rem; font-weight:600;">Rocket</span>
                            </label>

                            <!-- Card (Visa/MasterCard) -->
                            <label style="text-align:center; cursor:pointer; border:2px solid #ddd; padding:18px 12px; border-radius:10px; transition: all 0.3s;">
                                <input type="radio" name="method" value="card" style="display:none;">
                                <div style="display:flex; justify-content:center; gap:10px; margin-bottom:8px;">
                                    <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Visa.svg" alt="Visa" style="height:28px;">
                                    <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="MasterCard" style="height:38px;">
                                </div>
                                <span style="font-size:0.95rem; font-weight:600;">Card</span>
                            </label>

                            <!-- Nexus -->
                            <label style="text-align:center; cursor:pointer; border:2px solid #ddd; padding:18px 12px; border-radius:10px; transition: all 0.3s;">
                                <input type="radio" name="method" value="nexus" style="display:none;">
                                <img src="https://www.dutchbanglabank.com/img/nexsus_pay_logo.png" alt="NexusPay" style="height:50px; margin-bottom:8px;"><br>
                                <span style="font-size:0.95rem; font-weight:600;">Nexus</span>
                            </label>

                            <!-- Upay -->
                            <label style="text-align:center; cursor:pointer; border:2px solid #ddd; padding:18px 12px; border-radius:10px; transition: all 0.3s;">
                                <input type="radio" name="method" value="upay" style="display:none;">
                                <img src="https://images.seeklogo.com/logo-png/40/1/upay-logo-png_seeklogo-404483.png" alt="Upay" style="height:50px; margin-bottom:8px;"><br>
                                <span style="font-size:0.95rem; font-weight:600;">Upay</span>
                            </label>

                            <!-- Bank Transfer -->
                            <label style="text-align:center; cursor:pointer; border:2px solid #ddd; padding:18px 12px; border-radius:10px; transition: all 0.3s;">
                                <input type="radio" name="method" value="bank" style="display:none;">
                                <img src="https://uxwing.com/wp-content/themes/uxwing/download/banking-finance/bank-transfer-icon.png" alt="Bank" style="height:50px; margin-bottom:8px;"><br>
                                <span style="font-size:0.95rem; font-weight:600;">Bank</span>
                            </label>
                        </div>

                        <button type="submit" class="btn" style="width:100%; padding:15px; font-size:1.1rem;">
                            Continue to Payment
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <script>
        const price = {{ $chef['price'] }};
        const hoursInput = document.querySelector('input[name="hours"]');
        const totalSpan = document.getElementById('total');

        hoursInput.addEventListener('input', function() {
            const hours = this.value || 1;
            totalSpan.textContent = (price * hours).toLocaleString();
        });

        // Highlight selected payment method
        document.querySelectorAll('label[style*="cursor:pointer"]').forEach(label => {
            label.addEventListener('click', function() {
                document.querySelectorAll('label[style*="cursor:pointer"]').forEach(l => {
                    l.style.border = '2px solid #ddd';
                    l.style.boxShadow = 'none';
                });
                this.style.border = '2px solid var(--primary)';
                this.style.boxShadow = '0 5px 15px rgba(255,107,53,0.2)';
            });
        });
    </script>
</body>
</html>