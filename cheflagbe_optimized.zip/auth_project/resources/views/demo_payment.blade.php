<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Payment - ChefLagbe</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('chefs.css') }}">
</head>
<body>

<section class="section" style="padding: 100px 0; background: #f8f9fa;">
    <div class="container">
        <div class="chef-card" style="max-width: 500px; margin: 0 auto; text-align:center;">
            <div class="chef-info">
                <h2>Complete Your Payment</h2>
                <p><strong>Chef:</strong> {{ $chef['name'] }}</p>
                <p><strong>Hours:</strong> {{ $hours }}</p>
                <h1 style="color: var(--primary); margin: 20px 0;">৳{{ number_format($total) }}</h1>

                @php
                    $method = $request->method;
                    $logos = [
                        'bkash' => ['url' => 'https://upload.wikimedia.org/wikipedia/commons/9/97/Bkash.svg', 'name' => 'bKash'],
                        'nagad' => ['url' => 'https://upload.wikimedia.org/wikipedia/commons/5/5e/Nagad_Logo.svg', 'name' => 'Nagad'],
                        'rocket' => ['url' => 'https://seeklogo.com/images/D/dutch-bangla-rocket-logo-9B7C4E7A0A-seeklogo.com.png', 'name' => 'Rocket'],
                        'card'  => ['url' => 'https://upload.wikimedia.org/wikipedia/commons/0/04/Visa.svg', 'name' => 'Visa / MasterCard'],
                        'nexus' => ['url' => 'https://www.dbbl.com.bd/images/nexus-logo.png', 'name' => 'DBBL Nexus'],
                        'upay'  => ['url' => 'https://seeklogo.com/images/U/upay-logo-404483-new.png', 'name' => 'Upay'],
                        'bank'  => ['url' => 'https://uxwing.com/wp-content/themes/uxwing/download/banking-finance/bank-transfer-icon.png', 'name' => 'Bank Transfer'],
                    ];
                    $info = $logos[$method] ?? $logos['bkash'];
                    $pinText = in_array($method, ['card','nexus','bank']) ? 'OTP / Password' : 'PIN / OTP';
                @endphp

                <img src="{{ $info['url'] }}" alt="{{ $info['name'] }}" style="height: 70px; margin: 20px 0;">

                <form action="{{ url('/demo-pay') }}" method="POST" style="margin-top: 30px;">
                    @csrf
                    <p>Enter {{ $pinText }} (Demo: any 4 digits, e.g. 1234)</p>
                    <input type="text" name="otp_or_pin" maxlength="4" placeholder="••••" required 
                           style="text-align:center; font-size:2rem; letter-spacing:12px; width:220px; padding:15px; border:1px solid #ddd; border-radius:5px;">

                    <button type="submit" class="btn" style="width:100%; margin-top:20px;">
                        Pay ৳{{ number_format($total) }} via {{ $info['name'] }}
                    </button>
                </form>

                <p style="margin-top:30px; color:#666; font-size:0.9rem;">
                    This is a demo payment. No real money will be charged.
                </p>
            </div>
        </div>
    </div>
</section>
</body>
</html>