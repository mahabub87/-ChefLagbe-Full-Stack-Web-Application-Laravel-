<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ChefLagbe</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

   <link rel="stylesheet" href="{{asset("about.css")}}" />
</head>
<body>
    <!-- Header / Navigation Bar -->
    <header>
        <div class="container">
            <nav class="navbar">
                <a href="welcome" class="logo">
                    <img src="/CheefLogo.png" alt="Logo" style="height: 60px" />
                    ChefLagbe
                </a>
                
                <ul class="nav-links">
                    <li><a href="welcome">Home</a></li>
                    <li><a href="about">About</a></li>
                    <li><a href="services">Services</a></li>
                    <li><a href="chefs">Chefs</a></li>
                    <li><a href="contact">Contact</a></li>
                </ul>
                
                
                <div class="mobile-menu">
                    <i class="fas fa-bars"></i>
                </div>
            </nav>
        </div>
    </header>

    <!-- About Hero Section -->
    <section class="about-hero">
        <div class="container">
            <div class="about-hero-content">
                <h1>About ChefLagbe</h1>
                <p>Connecting food lovers with talented chefs to create exceptional culinary experiences</p>
                <a href="#our-story" class="btn">Our Story</a>
            </div>
        </div>
    </section>

    <!-- Our Story Section -->
    <section id="our-story" class="section">
        <div class="container">
            <div class="section-title">
                <h2>Our Story</h2>
                <p>How ChefLagbe began and our journey so far</p>
            </div>
            
            <div class="story-content">
                <div class="story-text">
                    <h2>From Passion to Platform</h2>
                    <p>ChefLagbe was founded in 2025 by culinary enthusiasts who recognized a gap in the market for connecting talented chefs with food lovers seeking exceptional dining experiences at home.</p>
                    <p>Our founder, Md. Naimul Islam noticed that many people wanted restaurant-quality meals for special occasions but didn't know how to find reliable, professional chefs. At the same time, talented chefs were looking for ways to expand their client base beyond traditional restaurant settings.</p>
                    <p>What started as a small local service in Dhaka has now grown into a nationwide platform connecting thousands of customers with hundreds of verified chefs across Bangladesh. We've facilitated over 10,000 culinary experiences, from intimate dinners to large corporate events.</p>
                    <p>Our mission remains the same: to make exceptional culinary experiences accessible to everyone while providing chefs with opportunities to showcase their talents and grow their businesses.</p>
                </div>
                <div class="story-image"></div>
            </div>
        </div>
    </section>

    <!-- Mission & Vision Section -->
    <section class="section mission-vision">
        <div class="container">
            <div class="section-title">
                <h2>Mission & Vision</h2>
                <p>What drives us forward</p>
            </div>
            
            <div class="mv-grid">
                <div class="mv-card">
                    <div class="mv-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h3>Our Mission</h3>
                    <p>To democratize access to exceptional culinary experiences by connecting food lovers with talented chefs, making restaurant-quality dining accessible in homes and events across Bangladesh.</p>
                </div>
                
                <div class="mv-card">
                    <div class="mv-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h3>Our Vision</h3>
                    <p>To become Bangladesh's most trusted platform for culinary experiences, empowering chefs to build sustainable businesses while delighting customers with unforgettable food moments.</p>
                </div>
                
                <div class="mv-card">
                    <div class="mv-icon">
                        <i class="fas fa-handshake"></i>
                    </div>
                    <h3>Our Promise</h3>
                    <p>We commit to providing verified, professional chefs, secure transactions, and exceptional customer service to ensure every culinary experience exceeds expectations.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section -->
    <section class="section">
        <div class="container">
            <div class="section-title">
                <h2>Our Values</h2>
                <p>The principles that guide everything we do</p>
            </div>
            
            <div class="values-grid">
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <h3>Quality</h3>
                    <p>We maintain the highest standards for our chefs and services to ensure exceptional experiences.</p>
                </div>
                
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Trust</h3>
                    <p>We verify all chefs and provide secure payment options to build confidence in our platform.</p>
                </div>
                
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>Passion</h3>
                    <p>We're driven by our love for food and creating memorable experiences for our customers.</p>
                </div>
                
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>Community</h3>
                    <p>We foster connections between food lovers and chefs, building a vibrant culinary community.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="section" style="background-color: #f8f9fa;">
        <div class="container">
            <div class="section-title">
                <h2>Meet Our Team</h2>
                <p>The passionate people behind ChefLagbe</p>
            </div>
            
            <div class="team-grid">
                <div class="team-card">
                    <div class="team-img" style="background-image: url('/Our-photo/ME.jpg');"></div>
                    <div class="team-info">
                        <h3>Md. Naimul Islam</h3>
                        <p class="position">Founder & CEO</p>
                        <p>Former event planner with 5+ years in the hospitality industry.</p>
                        <div class="team-social">
                            <a href="https://www.linkedin.com/in/naimul1322/"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-img" style="background-image: url('/Our-photo/jalal.jpg');"></div>
                    <div class="team-info">
                        <h3>Jalal Ahammed</h3>
                        <p class="position">Head of Operations</p>
                        <p>Previously managed operations for a chain of restaurants.</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-img" style="background-image: url('/Our-photo/Rana.jpg');"></div>
                    <div class="team-info">
                        <h3>Mehebub Rana</h3>
                        <p class="position">Chef Relations Manager</p>
                        <p>Former chef with a passion for connecting culinary talent.</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
                
                <div class="team-card">
                    <div class="team-img" style="background-image: url('/Our-photo/sangit.jpg');"></div>
                    <div class="team-info">
                        <h3>SM Sangit</h3>
                        <p class="position">Technology Lead</p>
                        <p>Ensures our platform provides the best user experience.</p>
                        <div class="team-social">
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="section stats">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-item">
                    <h3>5,000+</h3>
                    <p>Happy Customers</p>
                </div>
                
                <div class="stat-item">
                    <h3>500+</h3>
                    <p>Verified Chefs</p>
                </div>
                
                <div class="stat-item">
                    <h3>10,000+</h3>
                    <p>Successful Bookings</p>
                </div>
                
                <div class="stat-item">
                    <h3>50+</h3>
                    <p>Cities Served</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="container">
            <h2>Ready to Experience ChefLagbe?</h2>
            <p>Join thousands of satisfied customers who have discovered the joy of professional chef services at home.</p>
            <div class="cta-buttons">
                <a href="signup" class="btn">Sign Up Now</a>
                <a href="chefs" class="btn btn-outline" style="background-color: transparent; border: 2px solid white; color: white;">Browse Chefs</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>ChefLagbe</h3>
                    <p>Connecting food lovers with professional chefs for exceptional culinary experiences at home or events.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="welcome">Home</a></li>
                        <li><a href="about">About Us</a></li>
                        <li><a href="services">Services</a></li>
                        <li><a href="chefs">Chefs</a></li>
                        <li><a href="contact">Contact</a></li>
                    </ul>
                </div>
                
                <div class="footer-column">
                    <h3>Services</h3>
                    <ul class="footer-links">
                        <li><a href="#">Home Cooking</a></li>
                        <li><a href="#">Event Chef</a></li>
                        <li><a href="#">Catering Team</a></li>
                        <li><a href="#">Cooking Classes</a></li>
                        <li><a href="#">Meal Planning</a></li>
                    </ul>
                </div>
                
                <div class="footer-column">
                    <h3>Contact Us</h3>
                    <ul class="footer-links">
                        <li><i class="fas fa-map-marker-alt"></i> Daffodil Smart City (DSC), Dhaka,Bangladesh</li>
                        <li><i class="fas fa-phone"></i> +880 1797753943</li>
                        <li><i class="fas fa-envelope"></i> info@cheflagbe.com</li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2025 ChefLagbe. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>